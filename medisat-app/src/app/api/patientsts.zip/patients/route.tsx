import PatientModel from "@/db/models/Patients";
import { NextRequest } from "next/server";

export async function GET(request: NextRequest) {
  const searchParams = request.nextUrl.searchParams;
  const page = searchParams.get("page");
  const search = searchParams.get("search");

  const patient = await PatientModel.getAllPatients(page, search);
  console.log(patient);
  return Response.json(patient);
}
